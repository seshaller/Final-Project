function clickAWord(placeholder) {
    console.log(placeholder)
}