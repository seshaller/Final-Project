var DOGQUESTIONS = {
    q1: {
        response: null,
        question: "Is there someone home for more than 4 hours a day?"
    }
};

var container = document.querySelector('.container');
var btn1 = document.querySelector('.button-1');

btn1.addEventListener('click', function(event){
    var answer = event.target.innerText;

    DOGQUESTIONS.q1.response = answer;

    // container.innerHTML = `<button class="button-1">NOPE!</button>
    // <button class="button-2">I Party</button>
    // <button class="button-3">Still in my parents' basement</button>
    // <div class="dog">
    //     <img src="file:///Users/staceyshaller/Desktop/General%20Assembly-FEWD/Final/Images/pitbull-1.png" alt="dog">
    // </div>`;


    // Redirect them to page 2
});

var img = document.querySelector('.poodle');
var btn2 = document.querySelector(.'button-2');
btn2.addEventListener("mouseenter", function( event ) {   
    event.target.transform="poodle";
}


function clickAWord(placeholder) {
    console.log(placeholder)
}